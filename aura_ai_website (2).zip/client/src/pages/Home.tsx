import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowRight, Zap, Brain, Workflow, TrendingUp } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setEmail("");
      setTimeout(() => setSubmitted(false), 3000);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl">Aura</span>
          </div>
          <nav className="hidden md:flex gap-8">
            <a href="#features" className="text-sm hover:text-primary transition">Features</a>
            <a href="#vision" className="text-sm hover:text-primary transition">Vision</a>
            <a href="#signup" className="text-sm hover:text-primary transition">Early Access</a>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Anticipate. Automate. <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">Achieve.</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
              Your personal AI that works ahead of you. Aura proactively manages your tasks, automates complex workflows, and provides personalized insights to help you achieve true productivity and balance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
                Join the Waitlist <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline">
                Learn More
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="bg-muted/50 py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Features</h2>
              <p className="text-lg text-muted-foreground">Everything you need to transform your productivity</p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Feature 1 */}
              <Card className="border-border">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                      <Brain className="w-6 h-6 text-purple-500" />
                    </div>
                    <div>
                      <CardTitle>Proactive Scheduling</CardTitle>
                      <CardDescription>AI analyzes your calendar and emails to intelligently suggest, book, and reschedule meetings</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Feature 2 */}
              <Card className="border-border">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                      <Zap className="w-6 h-6 text-blue-500" />
                    </div>
                    <div>
                      <CardTitle>Contextual Communication</CardTitle>
                      <CardDescription>Aura drafts and prioritizes emails based on urgency, context, and your communication style</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Feature 3 */}
              <Card className="border-border">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                      <Workflow className="w-6 h-6 text-indigo-500" />
                    </div>
                    <div>
                      <CardTitle>Workflow Automation</CardTitle>
                      <CardDescription>Connect to your favorite tools and automate multi-step tasks across your entire tech stack</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Feature 4 */}
              <Card className="border-border">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                      <CardTitle>Personalized Insights</CardTitle>
                      <CardDescription>Daily summaries of critical tasks, potential conflicts, and cognitive load scoring</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>

        {/* Vision Section */}
        <section id="vision" className="container mx-auto px-4 py-20">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">The 5-Year Vision</h2>
            
            <div className="space-y-8">
              <div className="border-l-4 border-purple-500 pl-6">
                <h3 className="text-xl font-semibold mb-2">Market Trend Alignment</h3>
                <p className="text-muted-foreground">
                  Aura sits at the intersection of three massive growth markets: AI/Automation, Future of Work, and Personalized Wellness. The global AI market is projected to grow exponentially, positioning Aura to capture the personal productivity segment.
                </p>
              </div>

              <div className="border-l-4 border-blue-500 pl-6">
                <h3 className="text-xl font-semibold mb-2">Platform Strategy</h3>
                <p className="text-muted-foreground">
                  By year 3, Aura transitions from a standalone app to a Productivity Operating System. This involves opening an API for third-party developers to build "Aura Skills," creating a powerful, self-sustaining ecosystem.
                </p>
              </div>

              <div className="border-l-4 border-indigo-500 pl-6">
                <h3 className="text-xl font-semibold mb-2">Enterprise Adoption</h3>
                <p className="text-muted-foreground">
                  Initial focus on individual professionals leads to enterprise-level adoption. By year 5, Aura offers B2B solutions for teams, providing aggregated insights on team productivity and resource allocation.
                </p>
              </div>

              <div className="border-l-4 border-green-500 pl-6">
                <h3 className="text-xl font-semibold mb-2">Global Reach</h3>
                <p className="text-muted-foreground">
                  The core functionality is language and location-agnostic. The AI's ability to learn and adapt makes it highly scalable to diverse global markets with minimal localization effort.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Early Access Section */}
        <section id="signup" className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 py-20 border-y border-border">
          <div className="container mx-auto px-4 max-w-2xl">
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Join the Waitlist</h2>
              <p className="text-lg text-muted-foreground">
                Be among the first to experience the future of personal productivity
              </p>
            </div>

            <form onSubmit={handleSignup} className="flex flex-col sm:flex-row gap-3">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1"
              />
              <Button type="submit" className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 whitespace-nowrap">
                Get Early Access
              </Button>
            </form>

            {submitted && (
              <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-lg text-center text-green-700">
                ✓ Thanks for signing up! Check your email for updates.
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-muted/50 border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">Aura</h4>
              <p className="text-sm text-muted-foreground">Your personal AI that works ahead of you.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#features" className="hover:text-foreground transition">Features</a></li>
                <li><a href="#vision" className="hover:text-foreground transition">Vision</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition">About</a></li>
                <li><a href="#" className="hover:text-foreground transition">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <p className="text-sm text-muted-foreground">hello@aura.ai</p>
              <p className="text-sm text-muted-foreground">@AuraAI</p>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 Aura AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
